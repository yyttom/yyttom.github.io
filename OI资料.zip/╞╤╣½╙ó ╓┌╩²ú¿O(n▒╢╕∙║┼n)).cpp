#include<bits/stdc++.h>
#define maxn 40005
#define maxm 50005
#define maxb 205
using namespace std;
int n,m,h[maxn],v[maxn];//h��ɢ��Ľ����vӳ���ϵ
struct node{
    int value;
    int id;
    bool operator <(const node &y)const{
        return value<y.value;
    }
}h1[maxn];
int l[maxm],r[maxm];
int f[maxb][maxb],cnt[maxn],len,b[maxn];
//f��i��j���е�������cntͰ
int C[maxn][maxb];//һ������ĳ�����е���Ŀ
void Read(){//
    scanf("%d",&n);scanf("%d",&m);
    len=sqrt(n);
    for(int i=1;i<=n;++i){
        scanf("%d",&h[i]);
        h1[i].value=h[i];//����һ��
        h1[i].id=i;
        b[i]=(i-1)/len+1;
    }
    for(int i=1;i<=m;i++){
        scanf("%d%d",&l[i],&r[i]);
    }
}
void Disperse(){
    int id=0;
    sort(h1+1,h1+1+n);
    for(int i=1;i<=n;i++){
        if(h1[i].value!=h1[i-1].value){
            ++id;
            v[id]=h1[i].value;
        }
        h[h1[i].id]=id;
    }
}
void Pre(){
    int zs,t;
    for(int i=1;i<=n;i+=len){
        zs=0;
        for(int j=i;j<=n;j++){
            t=h[j];
            cnt[t]++;
            if(cnt[t]>cnt[zs] || (cnt[t]==cnt[zs] && v[t]<v[zs]))zs=t;
            f[b[i]][b[j]]=zs;
        }
        for(int j=i;j<=n;j++)cnt[h[j]]=0;
    }
    for(int i=1;i<=n;i++){
        C[h[i]][b[i]]++;//ĳ��ֵ��ĳ�����еĸ���
    }
    for(int i=1;i<=n;i++){
        for(int j=1;j<=b[n];j++){
            C[i][j]+=C[i][j-1];
        }
    }
}
void Run(){
    int L,R,zs=0,zsnum=0,e,tmp;
    for(int i=1;i<=m;++i){
        L=(l[i]+zs-1)%n+1;
        R=(r[i]+zs-1)%n+1;
        if(L>R)swap(L,R);
        //�м�
        zs=f[b[L]+1][b[R]-1];
        zsnum=C[zs][b[R]-1]-C[zs][b[L]];
        //���
        e=min(R,b[L]*len);
        for(int j=L;j<=e;++j){
            cnt[h[j]]++;
            tmp=cnt[h[j]]+(b[R]!=b[L]?C[h[j]][b[R]-1]-C[h[j]][b[L]]:0);
            if(tmp>zsnum || (tmp==zsnum && v[h[j]]<v[zs]))zs=h[j],zsnum=tmp;
        }
        //�ұ�
        if(b[L]!=b[R])
        for(int j=(b[R]-1)*len+1;j<=R;++j){
            cnt[h[j]]++;
            tmp=cnt[h[j]]+C[h[j]][b[R]-1]-C[h[j]][b[L]];
            if(tmp>zsnum || (tmp==zsnum && v[h[j]]<v[zs]))zs=h[j],zsnum=tmp;
        }
        
        zs=v[zs];
        printf("%d\n",zs);
        memset(cnt,0,sizeof(cnt));
        /*/cnt��0 ���
        for(int j=L;j<=e;++j){
            cnt[h[j]]=0;
        }
        //cnt��0 �ұ�
        if(b[L]!=b[R])
        for(int j=(b[R]-1)*len+1;j<=R;++j){
            cnt[h[j]]=0;
        }*/
    }
}
int main(){
    Read();
    Disperse();//��ɢ��
    Pre();//Ԥ����
    Run();
    return 0;
}
